function cds(){
    let n1 = [2, 3, 5, 6, ,9]
    let n2 = parseFloat(document.getElementById("numero").value)
    let suma = 0
    for ( let i = 0; i < n1.length; i++) {
        let n4 = +n1[i] ;
        suma += n4
        
    }
    if (n2 == suma){
        document.getElementById("resultado").innerText = "Es correcto"
    }
    else{
        document.getElementById("resultado").innerText = "no es correcto, Tienes que practicar"

    }
}


function nump() {
    let n1 = [ 2, 5, 9, 32, 22]
    let n2 = document.getElementById("numero").value
    let n4 = 0
    for (let i = 0; i < n1.length; i++) {
        if(n1[i] > n4){
            n4 = n1[i]

        }
    }
    if(n4 == n2){
        document.getElementById("resultado").innerText= "es correcto"

    }
    else{
        document.getElementById("resultado").innerText= "no es correcto"

    }


}


function ert() {
    let n4 = [ventana, becerro, algoritmo, laptop, caballo]
    let n6 = n4.split(",")
    for (let i = 0; i < n6.length; i++) {
        let n5 = Math.random(n6[i])
        
        
    }
}